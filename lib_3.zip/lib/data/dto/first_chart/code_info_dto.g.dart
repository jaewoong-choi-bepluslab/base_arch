// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'code_info_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_CodeInfoDto _$$_CodeInfoDtoFromJson(Map<String, dynamic> json) =>
    _$_CodeInfoDto(
      code: json['code'] as String? ?? '',
      system: json['system'] as String? ?? '',
      display: json['display'] as String? ?? '',
    );

Map<String, dynamic> _$$_CodeInfoDtoToJson(_$_CodeInfoDto instance) =>
    <String, dynamic>{
      'code': instance.code,
      'system': instance.system,
      'display': instance.display,
    };
