part of 'photo_bloc.dart';

sealed class PhotoEvent {}

final class PhotoStarted extends PhotoEvent {}
