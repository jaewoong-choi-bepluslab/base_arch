import 'package:base_architecture/domain/repository/repository.dart';
import 'package:base_architecture/domain/usecase/base/usecase.dart';

abstract interface class CommandUseCase<Repo extends Repository> {
  late final Repo repo;
  Future<T> execute<T>(Usecase usecase);
}
