import 'package:base_architecture/domain/repository/repository.dart';

abstract interface class Usecase<Repo extends Repository, T> {
  Future<T> call(Repo repository);
}
