import 'package:base_architecture/domain/repository/repository.dart';
import 'package:base_architecture/domain/repository/sample_repository.dart';
import 'package:base_architecture/domain/usecase/base/command_usecase.dart';
import 'package:base_architecture/domain/usecase/base/usecase.dart';

class SampleUsecase implements CommandUseCase<SampleRepository> {
  SampleUsecase(this.repo);

  @override
  SampleRepository repo;

  @override
  Future<T> execute<T>(Usecase<Repository, dynamic> usecase) {
    // TODO: implement execute
    throw UnimplementedError();
  }

  // @override
  // Future<T> execute<T>({required Usecase<Repository, T> usecase}) async {
  //   return await usecase(_sampleRepository);
  // }
}
